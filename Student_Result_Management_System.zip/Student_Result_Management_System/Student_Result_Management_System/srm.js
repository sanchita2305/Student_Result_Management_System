function result() {

    var students = {

      SANCHITA: 
      {
            DBMS: "89",
            OS: "88",
            CNS: "87",
            TOC: "84"
       },
      SIYA: 
      {
            DBMS: "88",
            OS: "86",
            CNS: "97",
            TOC: "87"
      },
      DIYA: 
      {
            DBMS: "98",
            OS: "90",
            CNS: "76",
            TOC: "88"
       },
      KARTIK: 
      {
            DBMS: "87",
            OS: "78",
            CNS: "70",
            TOC: "78"
       },
       SAKSHI:
       {
            DBMS: "90",
            OS: "88",
            CNS: "87",
            TOC: "89"
      },
       JAYDIP: 
      {
            DBMS: "95",
            OS: "88",
            CNS: "90",
            TOC: "90"
       },
       SANKET: 
      {
            DBMS: "89",
            OS: "88",
            CNS: "60",
            TOC: "77"
      },
      MEET:
      {
            DBMS: "98",
            OS: "88",
            CNS: "70",
            TOC: "48"
      },
        SHLOK:
       {
            DBMS: "90",
            OS: "89",
            CNS: "97",
            TOC: "84"
       },
       KIRTI: 
       {
            DBMS: "89",
            OS: "87",
            CNS: "87",
            TOC: "64"
       },
      AKSHADA:
       {
            DBMS: "76",
            OS: "88",
            CNS: "87",
            TOC: "74"
      },
      PRITI:
       {
            DBMS: "89",
            OS: "98",
            CNS: "70",
            TOC: "94"
      }




    }


   
    var studentname = document.getElementById('studentname').value;
    var input = studentname.toUpperCase();
    var definition = students[input];
    var output = document.getElementById("output");

    if (definition == undefined)
     {
          output.innerHTML = '<hr> There is no information about this student <hr>';
    } 
    else 
    {
      output.innerHTML = '<hr>DBMS Score:89 <hr> OS Score:98 <hr> CNS Score: 70 <hr> TOC Score:94<hr>';

    };
};
